# Télécharge les polices Google Fonts au moment du build et les range dans www/fonts/,
# pour que l'app s'affiche correctement sans internet.
import re, sys, hashlib, pathlib, urllib.request

UA = 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36'

def get(url):
    req = urllib.request.Request(url, headers={'User-Agent': UA})
    return urllib.request.urlopen(req, timeout=60).read()

www = pathlib.Path('www')
page = www / 'index.html'
html = page.read_text(encoding='utf-8')

m = re.search(r'<link href="(https://fonts\.googleapis\.com/css2[^"]+)" rel="stylesheet">', html)
if not m:
    print('Aucun lien Google Fonts trouvé : rien à faire.')
    sys.exit(0)

css = get(m.group(1).replace('&amp;', '&')).decode('utf-8')
(www / 'fonts').mkdir(exist_ok=True)

def grab(mo):
    url = mo.group(1)
    name = hashlib.sha1(url.encode()).hexdigest()[:12] + '.woff2'
    (www / 'fonts' / name).write_bytes(get(url))
    return 'url(fonts/%s)' % name

css = re.sub(r'url\((https://fonts\.gstatic\.com/[^)]+)\)', grab, css)
(www / 'fonts.css').write_text(css, encoding='utf-8')

html = html.replace(m.group(0), '<link rel="stylesheet" href="fonts.css">')
html = re.sub(r'<link rel="preconnect" href="https://fonts\.googleapis\.com">\s*', '', html)
page.write_text(html, encoding='utf-8')
print('Polices intégrées :', len(list((www / 'fonts').glob('*.woff2'))), 'fichiers')
